from flask import Flask, request, jsonify, render_template
import pickle
import numpy as np

app = Flask(__name__)

# Load the model
with open('svc_model.pkl', 'rb') as f:
    model = pickle.load(f)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    # Extract data from form
    data = [
        request.form['Gender'],
        request.form['Married'],
        request.form['Dependents'],
        request.form['Education'],
        request.form['Self_Employed'],
        float(request.form['ApplicantIncome']),
        float(request.form['CoapplicantIncome']),
        float(request.form['LoanAmount']),
        float(request.form['Loan_Amount_Term']),
        int(request.form['Credit_History']),
        request.form['Property_Area']
    ]

    # Convert categorical variables to numerical (this will depend on how your model was trained)
    data[0] = 1 if data[0] == 'Male' else 0
    data[1] = 1 if data[1] == 'Yes' else 0
    data[3] = 1 if data[3] == 'Graduate' else 0
    data[4] = 1 if data[4] == 'Yes' else 0
    data[10] = 0 if data[10] == 'Urban' else 1 if data[10] == 'Semiurban' else 2

    # Reshape and predict
    prediction = model.predict([data])[0]
    
    # Return result
    return jsonify({'prediction': 'Approved' if prediction == 1 else 'Rejected'})

if __name__ == '__main__':
    app.run(debug=True)

